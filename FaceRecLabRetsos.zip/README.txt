Instructions to run code:
1. Open visual studio, juypter notebook, or a similar program that can run ipynb files.
2. Load FaceRecLabRetsos.ipynb into your program.
3. Run code with a Python environment.
4. My file path for the dataset was "D:\AT&TDatabase", make sure to change this to your correct file path in Step 2 of the code.
5. Ensure your environment has the following packages installed: numpy, opencv-python (for cv2), matplotlib, and scipy. If any are missing, install them using pip.

If the code still does not run after these steps, double check to make sure your program and environment are set up properly.